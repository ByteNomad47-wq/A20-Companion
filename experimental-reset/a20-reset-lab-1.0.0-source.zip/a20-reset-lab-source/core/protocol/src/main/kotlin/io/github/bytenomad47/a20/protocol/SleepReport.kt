// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20.protocol

import java.time.Duration
import java.time.Instant

/** A local report grouping, retaining the source summaries; not Soundcore's report algorithm. */
data class SleepReport(
    val window: SleepMetricWindow,
    val sessions: List<SleepSession>,
    val spans: List<SleepStageSpan>,
    val conflicting: Duration,
    val ambiguous: Boolean,
) {
    /** Never average differing scores, or prefer one ear's score without an established rule. */
    val score: Int?
        get() = sessions.map { it.score }.distinct().singleOrNull()

    val totals: SleepStageTotals
        get() = SleepMetrics.calculate(window, spans)
}

object SleepReports {
    /**
     * Group strictly overlapping opposite-ear summaries, retaining separate naps and all members of
     * ambiguous many-to-one matches. Cumulative summary updates are collapsed by SleepSessions. No
     * timezone, clock padding or proximity threshold is used for grouping.
     */
    fun build(records: List<SleepRecord>, links: List<SleepEventLink>): List<SleepReport> {
        val sessions = SleepSessions.decode(records)
        val pending = sessions.toMutableSet()
        val reports = mutableListOf<SleepReport>()
        while (pending.isNotEmpty()) {
            val members = mutableListOf(pending.first())
            pending.remove(members.first())
            var index = 0
            while (index < members.size) {
                val current = members[index++]
                val matches = pending.filter {
                    it.source != current.source && it.start < current.end && current.start < it.end
                }
                members += matches
                pending.removeAll(matches.toSet())
            }
            members.sortWith(compareBy<SleepSession> { it.start }.thenBy { it.source })
            val window = SleepMetricWindow(members.minOf { it.start }, members.maxOf { it.end })
            val ambiguous = members.groupBy { it.source }.any { it.value.size > 1 }
            if (ambiguous) {
                reports +=
                    SleepReport(
                        window,
                        members,
                        listOf(SleepStageSpan(window.start, window.end, SleepStage.UNKNOWN)),
                        Duration.ZERO,
                        true,
                    )
                continue
            }
            val timelines = members.map { SleepTimelines.build(it, records, links) }
            reports += combine(window, members, timelines)
        }
        return reports.sortedWith(
            compareByDescending<SleepReport> { it.window.end }.thenBy { it.window.start }
        )
    }

    /**
     * A known state can come from one ear. When both have known states they must agree; otherwise
     * the interval is unknown. Missing/special states provide no contrary classification. This
     * conservative local policy deliberately does not imitate the unqualified official fusion.
     */
    private fun combine(
        window: SleepMetricWindow,
        members: List<SleepSession>,
        timelines: List<SleepTimeline>,
    ): SleepReport {
        data class Change(val source: Int, val stage: SleepStage?)
        val boundaries = sortedMapOf<Instant, MutableList<Change>>()
        boundaries[window.start] = mutableListOf()
        boundaries[window.end] = mutableListOf()
        for (timeline in timelines) {
            for (span in timeline.spans) {
                boundaries.getOrPut(span.start) { mutableListOf() } +=
                    Change(timeline.session.source, span.stage)
                boundaries.getOrPut(span.end) { mutableListOf() } +=
                    Change(timeline.session.source, null)
            }
        }
        val active = mutableMapOf<Int, SleepStage>()
        val spans = mutableListOf<SleepStageSpan>()
        var conflicting = Duration.ZERO
        for ((start, end) in boundaries.keys.toList().zipWithNext()) {
            // At a shared boundary remove old states before applying new states.
            val changes = boundaries.getValue(start)
            changes.filter { it.stage == null }.forEach { active.remove(it.source) }
            changes.filter { it.stage != null }.forEach { active[it.source] = it.stage!! }
            val known = active.values.filter { it != SleepStage.UNKNOWN }.distinct()
            val stage = known.singleOrNull() ?: SleepStage.UNKNOWN
            if (known.size > 1) conflicting += Duration.between(start, end)
            val previous = spans.lastOrNull()
            if (previous?.stage == stage && previous.end == start)
                spans[spans.lastIndex] = previous.copy(end = end)
            else spans += SleepStageSpan(start, end, stage)
        }
        return SleepReport(window, members, spans, conflicting, false)
    }
}
