// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20.protocol

import java.time.Duration
import java.time.Instant

/** A valid, device-reported summary from one ear. Interval length is not total sleep. */
data class SleepSession(
    val source: Int,
    val start: Instant,
    val end: Instant,
    val score: Int?,
) {
    val interval: Duration
        get() = Duration.between(start, end)
}

object SleepSessions {
    /**
     * 01.57 summary layout: LE start/end seconds, validity, score, WASO, period, efficiency. Only
     * validity=2 is a completed sleep summary. Other metrics are not combined here. Repeated
     * imports contain cumulative updates: keep the greatest end for each ear/start. Conflicting
     * scores at the same latest end remain unknown, independent of packet order.
     */
    fun decode(records: List<SleepRecord>): List<SleepSession> =
        records
            .mapNotNull { record ->
                if (record.kind != SleepRecordKind.SUMMARIES) return@mapNotNull null
                val bytes = record.hex.chunked(2).map { it.toInt(16) }
                fun seconds(offset: Int): Long =
                    (0..3).fold(0L) { value, i ->
                        value or (bytes[offset + i].toLong() shl (8 * i))
                    }
                val start = seconds(0)
                val end = seconds(4)
                // Exclude zero/unset clocks and corrupt dates; unsigned decoding avoids 2038
                // overflow.
                if (
                    bytes[8] != 2 ||
                        start !in 946684800L..4102444799L ||
                        end !in (start + 1)..4102444799L
                )
                    return@mapNotNull null
                SleepSession(
                    record.source,
                    Instant.ofEpochSecond(start),
                    Instant.ofEpochSecond(end),
                    bytes[9].takeIf { it in 0..100 },
                )
            }
            .groupBy { it.source to it.start }
            .values
            .map { updates ->
                val end = updates.maxOf { it.end }
                val latest = updates.filter { it.end == end }
                latest.first().copy(score = latest.map { it.score }.distinct().singleOrNull())
            }
            .sortedWith(
                compareByDescending<SleepSession> { it.end }
                    .thenBy { it.source }
                    .thenBy { it.start }
            )
}
