// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20.protocol

import java.time.Duration
import java.time.Instant
import kotlin.math.roundToInt

/** The explicit interval used for both a metric's numerator and its denominator. */
data class SleepMetricWindow(val start: Instant, val end: Instant) {
    init {
        require(end > start)
    }

    val duration: Duration
        get() = Duration.between(start, end)
}

/** Known durations remain useful for debugging; incomplete totals are not nightly metrics. */
data class SleepStageTotals(
    val window: SleepMetricWindow,
    val awake: Duration,
    val light: Duration,
    val deep: Duration,
    val unknown: Duration,
) {
    init {
        require(listOf(awake, light, deep, unknown).none { it.isNegative })
        require(awake + light + deep + unknown == window.duration)
    }

    val complete: Boolean
        get() = unknown.isZero

    val totalSleep: Duration?
        get() = if (complete) light + deep else null

    /** Rounded only at presentation time, using this same window throughout. */
    val efficiencyPercent: Int?
        get() = totalSleep?.let { (seconds(it) / seconds(window.duration) * 100).roundToInt() }

    fun duration(stage: SleepStage): Duration =
        when (stage) {
            SleepStage.AWAKE -> awake
            SleepStage.LIGHT -> light
            SleepStage.DEEP -> deep
            SleepStage.UNKNOWN -> unknown
        }

    /** Keep unrounded proportions so the UI can choose a consistent rounding policy. */
    fun percentage(stage: SleepStage): Double? =
        if (complete && stage != SleepStage.UNKNOWN)
            seconds(duration(stage)) / seconds(window.duration) * 100
        else null

    private fun seconds(duration: Duration): Double = duration.seconds + duration.nano / 1e9
}

object SleepMetrics {
    /**
     * Summarize already interpreted spans inside one declared window. This does not select a
     * session, fuse earbuds, decode special raw event codes, or extrapolate outside coverage.
     * Duplicate same-stage coverage is counted once. Gaps and conflicting coverage are unknown.
     */
    fun calculate(window: SleepMetricWindow, spans: List<SleepStageSpan>): SleepStageTotals {
        data class Change(val stage: SleepStage, val delta: Int)

        val changes = sortedMapOf<Instant, MutableList<Change>>()
        changes[window.start] = mutableListOf()
        changes[window.end] = mutableListOf()
        for (span in spans) {
            require(span.end >= span.start)
            val start = maxOf(window.start, span.start)
            val end = minOf(window.end, span.end)
            if (end <= start) continue
            changes.getOrPut(start) { mutableListOf() } += Change(span.stage, 1)
            changes.getOrPut(end) { mutableListOf() } += Change(span.stage, -1)
        }
        val totals = SleepStage.entries.associateWith { Duration.ZERO }.toMutableMap()
        val active = mutableMapOf<SleepStage, Int>()
        val boundaries = changes.keys.toList()
        for ((start, end) in boundaries.zipWithNext()) {
            for (change in changes.getValue(start)) {
                val count = active.getOrDefault(change.stage, 0) + change.delta
                if (count == 0) active.remove(change.stage) else active[change.stage] = count
            }
            val stage = active.keys.singleOrNull() ?: SleepStage.UNKNOWN
            totals[stage] = totals.getValue(stage) + Duration.between(start, end)
        }
        return SleepStageTotals(
            window,
            totals.getValue(SleepStage.AWAKE),
            totals.getValue(SleepStage.LIGHT),
            totals.getValue(SleepStage.DEEP),
            totals.getValue(SleepStage.UNKNOWN),
        )
    }
}
