// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20.protocol

import java.time.Instant

enum class SleepStage {
    AWAKE,
    LIGHT,
    DEEP,
    UNKNOWN,
}

/**
 * Adjacent events received together in one complete source history, never inferred from imports.
 */
data class SleepEventLink(val before: SleepRecord, val after: SleepRecord) {
    init {
        require(before.kind == SleepRecordKind.EVENTS && after.kind == SleepRecordKind.EVENTS)
        require(before.source == after.source)
    }
}

data class SleepTimelinePoint(val time: Instant, val stage: SleepStage, val movements: Int?)

data class SleepStageSpan(val start: Instant, val end: Instant, val stage: SleepStage)

data class SleepTimeline(
    val session: SleepSession,
    val spans: List<SleepStageSpan>,
    val points: List<SleepTimelinePoint>,
) {
    val partial: Boolean
        get() = spans.any { it.stage == SleepStage.UNKNOWN }

    val reportedMovements: Int
        get() = points.sumOf { it.movements ?: 0 }
}

object SleepTimelines {
    private data class Event(
        val record: SleepRecord,
        val time: Instant,
        val code: Int,
        val movements: Int,
    ) {
        val stage: SleepStage
            get() =
                when (code) {
                    1 -> SleepStage.AWAKE
                    2 -> SleepStage.LIGHT
                    3 -> SleepStage.DEEP
                    else -> SleepStage.UNKNOWN
                }
    }

    private fun event(record: SleepRecord): Event? {
        if (record.kind != SleepRecordKind.EVENTS) return null
        val b = record.hex.chunked(2).map { it.toInt(16) }
        val seconds = (0..3).fold(0L) { value, i -> value or (b[i].toLong() shl (8 * i)) }
        if (seconds !in 946684800L..4102444799L) return null
        return Event(record, Instant.ofEpochSecond(seconds), b[4] and 15, b[5])
    }

    /**
     * Call only with a complete, freshly assembled per-ear response. Invalid clocks break coverage.
     */
    fun linksFromSnapshot(records: List<SleepRecord>): List<SleepEventLink> {
        if (records.size > 100 || records.map { it.source }.distinct().size > 1) return emptyList()
        val events = records.distinct().map { event(it) ?: return emptyList() }
        // The firmware exports physical ring order. Sorting restores chronological order.
        // Multiple different records at one second have no qualified ordering: leave a gap.
        return events
            .groupBy { it.time }
            .toSortedMap()
            .values
            .zipWithNext()
            .mapNotNull { (a, b) ->
                if (a.size != 1 || b.size != 1) null
                else SleepEventLink(a.single().record, b.single().record)
            }
    }

    fun build(
        session: SleepSession,
        records: List<SleepRecord>,
        links: List<SleepEventLink>,
    ): SleepTimeline {
        val retained = records.toHashSet()
        val groups =
            records
                .distinct()
                .filter { it.source == session.source }
                .mapNotNull(::event)
                .groupBy { it.time }
                .toSortedMap()
        val points = groups.map { (time, events) ->
            SleepTimelinePoint(
                time,
                if (events.map { it.code }.distinct().size == 1) events.first().stage
                else SleepStage.UNKNOWN,
                events.map { it.movements }.distinct().singleOrNull(),
            )
        }
        val indices = points.mapIndexed { i, point -> point.time to i }.toMap()
        val known =
            links
                .distinct()
                .mapNotNull { link ->
                    if (
                        link.before.source != session.source ||
                            link.before !in retained ||
                            link.after !in retained
                    )
                        return@mapNotNull null
                    val a = event(link.before) ?: return@mapNotNull null
                    val b = event(link.after) ?: return@mapNotNull null
                    val index = indices[a.time] ?: return@mapNotNull null
                    // A later import may reveal an intervening event. Do not draw across it.
                    if (indices[b.time] != index + 1 || points[index].stage == SleepStage.UNKNOWN)
                        return@mapNotNull null
                    val start = maxOf(a.time, session.start)
                    val end = minOf(b.time, session.end)
                    if (end <= start) null else SleepStageSpan(start, end, points[index].stage)
                }
                .distinct()
                .sortedBy { it.start }
        val spans = mutableListOf<SleepStageSpan>()
        var cursor = session.start
        for (span in known) {
            if (span.start > cursor) spans += SleepStageSpan(cursor, span.start, SleepStage.UNKNOWN)
            spans += span
            cursor = span.end
        }
        if (cursor < session.end) spans += SleepStageSpan(cursor, session.end, SleepStage.UNKNOWN)
        return SleepTimeline(
            session,
            spans,
            points.filter { it.time >= session.start && it.time < session.end },
        )
    }
}
