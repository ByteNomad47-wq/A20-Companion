// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20.protocol

import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import org.junit.Assert.*
import org.junit.Test

class SleepMetricsTest {
    private val origin = Instant.parse("2025-04-03T00:00:00Z")
    private val window = SleepMetricWindow(origin, origin.plusSeconds(3600))

    private fun span(from: Long, to: Long, stage: SleepStage) =
        SleepStageSpan(origin.plusSeconds(from), origin.plusSeconds(to), stage)

    @Test
    fun completeCoverageKeepsExactDurationsBeforeDisplayRounding() {
        val result =
            SleepMetrics.calculate(
                window,
                listOf(
                    span(0, 601, SleepStage.AWAKE),
                    span(601, 2402, SleepStage.LIGHT),
                    span(2402, 3600, SleepStage.DEEP),
                ),
            )
        assertTrue(result.complete)
        assertEquals(Duration.ofSeconds(2999), result.totalSleep)
        assertEquals(83, result.efficiencyPercent)
        assertEquals(1801.0 / 36, result.percentage(SleepStage.LIGHT)!!, 1e-10)
        assertEquals(
            100.0,
            listOf(SleepStage.AWAKE, SleepStage.LIGHT, SleepStage.DEEP).sumOf {
                result.percentage(it)!!
            },
            1e-10,
        )
        assertEquals(49L, result.totalSleep!!.toMinutes())
    }

    @Test
    fun partialHistoryDoesNotTurnIntoZeroSleepOrACompleteNight() {
        val result = SleepMetrics.calculate(window, listOf(span(600, 1800, SleepStage.LIGHT)))
        assertEquals(Duration.ofSeconds(2400), result.unknown)
        assertEquals(Duration.ofSeconds(1200), result.light)
        assertNull(result.totalSleep)
        assertNull(result.efficiencyPercent)
        assertNull(result.percentage(SleepStage.LIGHT))
        val empty = SleepMetrics.calculate(window, emptyList())
        assertEquals(window.duration, empty.unknown)
        assertNull(empty.totalSleep)
    }

    @Test
    fun repeatedAndOverlappingSameStageRecordsAreNotDoubleCounted() {
        val a = span(0, 2400, SleepStage.LIGHT)
        val result =
            SleepMetrics.calculate(
                window,
                listOf(
                    a,
                    a,
                    span(1200, 3600, SleepStage.LIGHT),
                    span(900, 900, SleepStage.DEEP),
                ),
            )
        assertEquals(window.duration, result.light)
        assertEquals(100, result.efficiencyPercent)
    }

    @Test
    fun conflictingSpansOnlyInvalidateTheirOverlapRegardlessOfInputOrder() {
        val spans = listOf(span(0, 2400, SleepStage.LIGHT), span(1200, 3600, SleepStage.DEEP))
        val result = SleepMetrics.calculate(window, spans)
        assertEquals(result, SleepMetrics.calculate(window, spans.reversed()))
        assertEquals(Duration.ofSeconds(1200), result.light)
        assertEquals(Duration.ofSeconds(1200), result.deep)
        assertEquals(Duration.ofSeconds(1200), result.unknown)
        assertNull(result.totalSleep)
    }

    @Test
    fun summaryWindowClipsWiderGraphInsteadOfProducingOver100PercentEfficiency() {
        val result =
            SleepMetrics.calculate(
                window,
                listOf(
                    span(-600, 4200, SleepStage.LIGHT),
                    span(-900, -600, SleepStage.AWAKE),
                ),
            )
        assertEquals(window.duration, result.totalSleep)
        assertEquals(100, result.efficiencyPercent)
    }

    @Test
    fun explicitUnknownCannotBeOverwrittenByAnotherSourceGuess() {
        val result =
            SleepMetrics.calculate(
                window,
                listOf(
                    span(0, 3600, SleepStage.LIGHT),
                    span(1200, 1800, SleepStage.UNKNOWN),
                ),
            )
        assertEquals(Duration.ofSeconds(600), result.unknown)
        assertNull(result.totalSleep)
    }

    @Test
    fun repeatedClockHourUsesRealElapsedTimeAcrossDaylightSavingTransition() {
        val paris = ZoneId.of("Europe/Paris")
        val start = java.time.LocalDateTime.parse("2025-10-26T01:30:00").atZone(paris).toInstant()
        val end = java.time.LocalDateTime.parse("2025-10-26T03:30:00").atZone(paris).toInstant()
        val interval = SleepMetricWindow(start, end)
        val result =
            SleepMetrics.calculate(interval, listOf(SleepStageSpan(start, end, SleepStage.DEEP)))
        assertEquals(Duration.ofHours(3), result.totalSleep)
        assertEquals(100, result.efficiencyPercent)
    }

    @Test
    fun subSecondBoundariesDoNotDiscardTimeOrInventGaps() {
        val mid = origin.plusMillis(500)
        val interval = SleepMetricWindow(origin, origin.plusSeconds(1))
        val result =
            SleepMetrics.calculate(
                interval,
                listOf(
                    SleepStageSpan(origin, mid, SleepStage.AWAKE),
                    SleepStageSpan(mid, interval.end, SleepStage.LIGHT),
                ),
            )
        assertEquals(Duration.ofMillis(500), result.totalSleep)
        assertEquals(50, result.efficiencyPercent)
    }

    @Test
    fun invalidWindowsAndReversedSpansAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { SleepMetricWindow(origin, origin) }
        assertThrows(IllegalArgumentException::class.java) {
            SleepMetrics.calculate(window, listOf(span(1200, 600, SleepStage.LIGHT)))
        }
    }
}
