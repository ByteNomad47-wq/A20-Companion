// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.time.Duration
import java.time.Instant
import org.junit.Assert.*
import org.junit.Test

class SleepTimelineTest {
    private val origin = Instant.parse("2025-04-03T00:00:00Z")

    private fun event(seconds: Long, code: Int, turns: Int = 0, source: Int = 0): SleepRecord {
        val b =
            ByteBuffer.allocate(6)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(origin.epochSecond.toInt() + seconds.toInt())
                .put(code.toByte())
                .put(turns.toByte())
                .array()
        return SleepRecord(
            SleepRecordKind.EVENTS,
            source,
            b.joinToString("") { "%02x".format(it.toInt() and 255) },
        )
    }

    private fun session(source: Int = 0, from: Long = 0, to: Long = 3600) =
        SleepSession(source, origin.plusSeconds(from), origin.plusSeconds(to), 80)

    @Test
    fun chronologicalRingOrderAndPostureBitsDoNotChangeStageMeaning() {
        val events = listOf(event(2400, 0x33), event(3600, 4), event(0, 0x11), event(1200, 0x22))
        val result =
            SleepTimelines.build(session(), events, SleepTimelines.linksFromSnapshot(events))
        assertEquals(
            listOf(SleepStage.AWAKE, SleepStage.LIGHT, SleepStage.DEEP),
            result.spans.map { it.stage },
        )
        assertFalse(result.partial)
        assertEquals(3600L, result.spans.sumOf { Duration.between(it.start, it.end).seconds })
    }

    @Test
    fun missingBeginningAndEndAreUnknownWithoutExtrapolation() {
        val events = listOf(event(600, 2), event(2400, 3))
        val result =
            SleepTimelines.build(session(), events, SleepTimelines.linksFromSnapshot(events))
        assertEquals(
            listOf(SleepStage.UNKNOWN, SleepStage.LIGHT, SleepStage.UNKNOWN),
            result.spans.map { it.stage },
        )
        assertTrue(result.partial)
    }

    @Test
    fun separateImportsNeverCreateAnUnobservedBridge() {
        val a = listOf(event(0, 2), event(600, 3))
        val b = listOf(event(2400, 1), event(3600, 4))
        val result =
            SleepTimelines.build(
                session(),
                a + b,
                SleepTimelines.linksFromSnapshot(a) + SleepTimelines.linksFromSnapshot(b),
            )
        assertEquals(
            listOf(SleepStage.LIGHT, SleepStage.UNKNOWN, SleepStage.AWAKE),
            result.spans.map { it.stage },
        )
    }

    @Test
    fun legacyImportsKeepObservationsButDoNotInventCoverage() {
        val events = listOf(event(0, 2, 7), event(1200, 3, 5))
        val result = SleepTimelines.build(session(), events, emptyList())
        assertEquals(SleepStage.UNKNOWN, result.spans.single().stage)
        assertEquals(2, result.points.size)
        assertEquals(12, result.reportedMovements)
    }

    @Test
    fun specialWakeStopAndUnmappedCodesStayUnknown() {
        for (code in listOf(0, 4, 5, 6, 10, 15)) {
            val events = listOf(event(0, code), event(3600, 2))
            val result =
                SleepTimelines.build(session(), events, SleepTimelines.linksFromSnapshot(events))
            assertEquals(SleepStage.UNKNOWN, result.spans.single().stage)
        }
    }

    @Test
    fun peerHistoryCannotFillMissingDataForSelectedEar() {
        val events = listOf(event(0, 2, source = 1), event(3600, 3, source = 1))
        val result =
            SleepTimelines.build(session(), events, SleepTimelines.linksFromSnapshot(events))
        assertTrue(result.points.isEmpty())
        assertEquals(SleepStage.UNKNOWN, result.spans.single().stage)
    }

    @Test
    fun conflictingTimestampsHaveNoInventedOrderingOrMovementTotals() {
        val events = listOf(event(0, 2, 3), event(0, 3, 7), event(3600, 1))
        assertTrue(SleepTimelines.linksFromSnapshot(events).isEmpty())
        val result = SleepTimelines.build(session(), events, emptyList())
        assertEquals(SleepStage.UNKNOWN, result.points.first().stage)
        assertNull(result.points.first().movements)
    }

    @Test
    fun orphanLinksAndLaterInterveningEventsDoNotCreateFalseCoverage() {
        val a = event(0, 2)
        val b = event(3600, 3)
        val links = SleepTimelines.linksFromSnapshot(listOf(a, b))
        assertTrue(SleepTimelines.build(session(), listOf(a), links).partial)
        val changed = SleepTimelines.build(session(), listOf(a, event(1800, 1), b), links)
        assertTrue(changed.spans.all { it.stage == SleepStage.UNKNOWN })
    }

    @Test
    fun clippingAndBoundariesKeepMovementReportsInsideTheSelectedInterval() {
        val events = listOf(event(-600, 2, 9), event(1200, 3, 7), event(3600, 1, 5))
        val result =
            SleepTimelines.build(session(), events, SleepTimelines.linksFromSnapshot(events))
        assertEquals(origin, result.spans.first().start)
        assertEquals(origin.plusSeconds(3600), result.spans.last().end)
        assertEquals(7, result.reportedMovements)
        assertEquals(origin.plusSeconds(1200), result.points.single().time)
    }

    @Test
    fun corruptClocksAndMixedOrOversizedSnapshotsDoNotQualifyLinks() {
        val a = event(0, 2)
        val b = event(600, 3)
        val corrupt = SleepRecord(SleepRecordKind.EVENTS, 0, "000000000200")
        assertTrue(SleepTimelines.linksFromSnapshot(listOf(a, corrupt, b)).isEmpty())
        assertTrue(SleepTimelines.linksFromSnapshot(listOf(a, event(600, 3, source = 1))).isEmpty())
        assertTrue(SleepTimelines.linksFromSnapshot(List(101) { a }).isEmpty())
    }
}
