// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.time.Instant
import java.time.ZoneId
import org.junit.Assert.*
import org.junit.Test

class SleepSessionTest {
    private val start = Instant.parse("2025-04-02T22:00:00Z").epochSecond

    private fun summary(
        source: Int = 0,
        from: Long = start,
        to: Long = start + 3600,
        validity: Int = 2,
        score: Int = 80,
    ): SleepRecord {
        val b =
            ByteBuffer.allocate(14)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(from.toInt())
                .putInt(to.toInt())
                .put(validity.toByte())
                .put(score.toByte())
                .put(255.toByte())
                .putShort(65535.toShort())
                .put(255.toByte())
                .array()
        return SleepRecord(
            SleepRecordKind.SUMMARIES,
            source,
            b.joinToString("") { "%02x".format(it.toInt() and 255) },
        )
    }

    @Test
    fun retainsLatestCumulativeUpdateWithoutCombiningEarsOrAddingDurations() {
        val records =
            listOf(
                summary(to = start + 1800, score = 60),
                summary(),
                summary(source = 1, score = 70),
                summary(),
            )
        val sessions = SleepSessions.decode(records)
        assertEquals(2, sessions.size)
        assertEquals(listOf(80, 70), sessions.map { it.score })
        assertTrue(sessions.all { it.interval.toMinutes() == 60L })
        assertEquals(sessions, SleepSessions.decode(records.reversed()))
    }

    @Test
    fun doesNotInferSleepTimeFromInvalidPeriodOrWasoFields() {
        val session = SleepSessions.decode(listOf(summary())).single()
        assertEquals(80, session.score)
        assertEquals(Instant.ofEpochSecond(start), session.start)
        assertEquals(60L, session.interval.toMinutes())
    }

    @Test
    fun rejectsInvalidSummariesAndUnsetOrReversedClocks() {
        assertTrue(
            SleepSessions.decode(
                    listOf(
                        summary(validity = 1),
                        summary(from = 0),
                        summary(to = start),
                        summary(to = start - 1),
                    )
                )
                .isEmpty()
        )
    }

    @Test
    fun unknownAndConflictingScoresAreNotShownAsZero() {
        assertNull(SleepSessions.decode(listOf(summary(score = 255))).single().score)
        val records = listOf(summary(score = 80), summary(score = 81))
        assertNull(SleepSessions.decode(records).single().score)
        assertEquals(SleepSessions.decode(records), SleepSessions.decode(records.reversed()))
    }

    @Test
    fun durationUsesElapsedTimeAcrossParisClockChange() {
        val from = Instant.parse("2025-10-25T23:30:00Z")
        val to = Instant.parse("2025-10-26T02:30:00Z")
        val session =
            SleepSessions.decode(listOf(summary(from = from.epochSecond, to = to.epochSecond)))
                .single()
        assertEquals(180L, session.interval.toMinutes())
        val paris = ZoneId.of("Europe/Paris")
        assertEquals(1, session.start.atZone(paris).hour)
        assertEquals(3, session.end.atZone(paris).hour)
    }

    @Test
    fun unsignedDatesAfter2038AndMultipleSessionsOnOneNightAreRetained() {
        val future = Instant.parse("2040-01-03T01:00:00Z").epochSecond
        val sessions =
            SleepSessions.decode(
                listOf(
                    summary(from = future, to = future + 3600),
                    summary(from = future + 7200, to = future + 10800),
                )
            )
        assertEquals(2, sessions.size)
        assertEquals(Instant.ofEpochSecond(future + 10800), sessions.first().end)
    }
}
