// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.time.Duration
import java.time.Instant
import org.junit.Assert.*
import org.junit.Test

class SleepReportTest {
    private val origin = Instant.parse("2025-04-03T00:00:00Z")

    private fun encoded(kind: SleepRecordKind, source: Int, bytes: ByteArray) =
        SleepRecord(kind, source, bytes.joinToString("") { "%02x".format(it.toInt() and 255) })

    private fun summary(source: Int, start: Int, end: Int, score: Int = 80) =
        encoded(
            SleepRecordKind.SUMMARIES,
            source,
            ByteBuffer.allocate(14)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(origin.epochSecond.toInt() + start)
                .putInt(origin.epochSecond.toInt() + end)
                .put(2)
                .put(score.toByte())
                .put(0)
                .putShort(0)
                .put(0)
                .array(),
        )

    private fun event(source: Int, time: Int, code: Int) =
        encoded(
            SleepRecordKind.EVENTS,
            source,
            ByteBuffer.allocate(6)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(origin.epochSecond.toInt() + time)
                .put(code.toByte())
                .put(0)
                .array(),
        )

    private fun build(summaries: List<SleepRecord>, vararg events: List<SleepRecord>) =
        SleepReports.build(
            summaries + events.flatMap { it },
            events.flatMap { SleepTimelines.linksFromSnapshot(it) },
        )

    @Test
    fun overlappingEarsProduceOneWindowWithoutAddingTheirDurations() {
        val report = build(listOf(summary(0, 0, 3600), summary(1, 600, 4200))).single()
        assertEquals(2, report.sessions.size)
        assertEquals(Duration.ofSeconds(4200), report.window.duration)
        assertEquals(80, report.score)
        assertFalse(report.totals.complete)
    }

    @Test
    fun napsAndTouchingIntervalsRemainSeparate() {
        val reports =
            build(listOf(summary(0, 0, 3600), summary(1, 3600, 4200), summary(0, 6000, 7200)))
        assertEquals(3, reports.size)
        assertEquals(
            listOf(7200L, 4200L, 3600L),
            reports.map { Duration.between(origin, it.window.end).seconds },
        )
    }

    @Test
    fun cumulativeUpdatesAreCollapsedBeforeGrouping() {
        val report =
            build(
                    listOf(
                        summary(0, 0, 1800, 70),
                        summary(0, 0, 3600, 80),
                        summary(1, 600, 3000, 80),
                    )
                )
                .single()
        assertEquals(2, report.sessions.size)
        assertEquals(80, report.score)
    }

    @Test
    fun differingOrMissingScoresNeverBecomeAnInventedCombinedScore() {
        assertNull(build(listOf(summary(0, 0, 3600, 70), summary(1, 0, 3600, 90))).single().score)
        assertNull(build(listOf(summary(0, 0, 3600, 80), summary(1, 0, 3600, 255))).single().score)
        assertEquals(0, build(listOf(summary(0, 0, 3600, 0))).single().score)
    }

    @Test
    fun sameEarOverlapIsNotMergedWithoutOppositeEarEvidence() {
        assertEquals(2, build(listOf(summary(0, 0, 2400), summary(0, 1200, 3600))).size)
    }

    @Test
    fun manyToOneMatchKeepsAllSourcesAndWithholdsTimelineInsteadOfGuessing() {
        val report =
            build(listOf(summary(0, 0, 1800), summary(0, 2400, 3600), summary(1, 600, 3000)))
                .single()
        assertTrue(report.ambiguous)
        assertEquals(3, report.sessions.size)
        assertEquals(SleepStage.UNKNOWN, report.spans.single().stage)
        assertNull(report.totals.totalSleep)
    }

    @Test
    fun agreeingEarsAndSingleSourceEdgesProvideContinuousKnownCoverage() {
        val report =
            build(
                    listOf(summary(0, 0, 3600), summary(1, 600, 4200)),
                    listOf(event(0, 0, 2), event(0, 3600, 2)),
                    listOf(event(1, 600, 2), event(1, 4200, 2)),
                )
                .single()
        assertEquals(Duration.ofSeconds(4200), report.totals.totalSleep)
        assertEquals(100, report.totals.efficiencyPercent)
        assertEquals(Duration.ZERO, report.conflicting)
    }

    @Test
    fun disagreementBecomesUnknownOnlyWhereBothEarsHaveConflictingKnownStates() {
        val report =
            build(
                    listOf(summary(0, 0, 3600), summary(1, 0, 3600)),
                    listOf(event(0, 0, 2), event(0, 1800, 3), event(0, 3600, 1)),
                    listOf(event(1, 0, 2), event(1, 2400, 3), event(1, 3600, 1)),
                )
                .single()
        assertEquals(Duration.ofSeconds(600), report.conflicting)
        assertEquals(Duration.ofSeconds(600), report.totals.unknown)
        assertNull(report.totals.totalSleep)
        assertEquals(
            listOf(SleepStage.LIGHT, SleepStage.UNKNOWN, SleepStage.DEEP),
            report.spans.map { it.stage },
        )
    }

    @Test
    fun oneEarAndSpecialPeerCodesDoNotRequireBothEarsToBePresent() {
        val events = listOf(event(0, 0, 2), event(0, 3600, 1))
        val single = build(listOf(summary(0, 0, 3600)), events).single()
        assertTrue(single.totals.complete)
        val peer =
            build(
                    listOf(summary(0, 0, 3600), summary(1, 0, 3600)),
                    events,
                    listOf(event(1, 0, 6), event(1, 3600, 4)),
                )
                .single()
        assertEquals(single.totals.totalSleep, peer.totals.totalSleep)
    }

    @Test
    fun separateImportsAndLegacyRecordsCannotFillMissingCoverage() {
        val a = listOf(event(0, 0, 2), event(0, 1200, 2))
        val b = listOf(event(0, 2400, 2), event(0, 3600, 2))
        val report = build(listOf(summary(0, 0, 3600)), a, b).single()
        assertEquals(Duration.ofSeconds(1200), report.totals.unknown)
        assertNull(report.totals.totalSleep)
        val legacy = SleepReports.build(listOf(summary(0, 0, 3600)) + a + b, emptyList()).single()
        assertEquals(legacy.window.duration, legacy.totals.unknown)
    }

    @Test
    fun groupingAndCoverageDoNotDependOnPacketOrder() {
        val summaries = listOf(summary(0, 0, 3600), summary(1, 600, 4200))
        val events = listOf(event(0, 0, 2), event(0, 3600, 1), event(1, 600, 2), event(1, 4200, 1))
        val links =
            events.groupBy { it.source }.values.flatMap { SleepTimelines.linksFromSnapshot(it) }
        val records = summaries + events
        assertEquals(
            SleepReports.build(records, links),
            SleepReports.build(records.reversed(), links.reversed()),
        )
    }
}
