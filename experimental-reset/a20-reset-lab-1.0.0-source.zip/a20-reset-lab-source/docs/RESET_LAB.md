# A20 Reset Lab — separate experimental app

Package: `io.github.bytenomad47.a20.resetlab`. Version: `1.0.0-reset-lab`.
It installs alongside the normal Companion, with separate local data and signing
identity. It does not update or weaken the normal app. No Internet permission.

This build removes the **firmware-version restriction for manual resets only**.
It is intended for an explicitly informed test on original A6611 firmware 01.58.
The reset semantics have only been examined/tested physically on 01.57. Reply
format compatibility does not prove command compatibility on another firmware.
The app cannot undo cleared records. A returning low count alone does not establish
that a reset is necessary or that a battery is healthy.

## Friend's procedure

1. Confirm **original Sleep A20, A6611**, on the case/box. A matching Bluetooth
   name is not independent hardware identification. Pair in Android settings.
2. Close Soundcore and Companion so they release their control connections.
3. Open **A20 Reset Lab**, grant Nearby Devices access, and choose the paired A20.
4. Open **experimental reset**, choose **one side**, and keep the other earbud in
   the closed case. Connect only the selected earbud.
5. Read the warning and explicitly confirm one manual reset. Stop if it reports a
   protocol/identity/voltage error. There are no automatic clear retries.
6. Open **Advanced → Export latest report**, and send that JSON privately. A lost
   reply can leave the outcome unknown; do not assume a failed message means the
   clear was never delivered. Any repeat needs a fresh explicit confirmation.
7. Observe subsequent charging. An acknowledgement alone does not verify main
   counter zero, power-loss persistence, battery health, or charging recovery.

It clears persistent charging records and may restore a higher charging target.
Do not use on an unusually hot or damaged earbud; supervise the next charge.
This app installs no firmware and performs no downgrade.

## Retained checks

- Exact original-A20 Bluetooth-name filtering (no other-device picker in Lab) and known status-response layout.
- Fresh normal status; requested ear must be primary and peer must be absent.
- Cached voltage reply for the same ear, in the existing 3400–4200 mV range.
  This is a cached reading, not a battery-health test.
- Existing known-format timing record, valid and unlocked, plus exact clear reply.
- Durable pair/ear/request-bound receipt before the single clear byte; no automatic
  retry, no reset on launch, and no exported reset API.

The sequence stays `4 → 2 → 3 → 2`. Main-counter command `7` is not used by reset.
Unqualified main-counter reads remain blocked and the Lab UI hides that action.
Reports record the actual reported firmware and mark the version gate as bypassed.
A device with a changed protocol can still be refused; version bypass is not a
promise that every firmware works. No raw Bluetooth address/name is exported.

## Build

Normal builds keep `RESET_LAB=false` and their existing package/version:

```sh
./gradlew :app:testDebugUnitTest --tests '*repair.*'
```

To build the separate experiment:

```sh
./gradlew -Pa20ResetLab=true :app:assembleRelease :app:lintRelease
```

Use a dedicated signing key stored outside Git via the existing signing environment
variables described in BUILD.md. Never use this APK to replace the normal app.
The Lab manifest removes launcher shortcuts, widgets, automation receiver and the
Quick Settings tile. Normal Companion UI/features remain unchanged in normal builds.
