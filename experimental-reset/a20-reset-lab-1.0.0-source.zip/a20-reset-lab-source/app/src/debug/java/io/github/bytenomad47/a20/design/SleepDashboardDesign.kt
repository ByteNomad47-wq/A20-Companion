// SPDX-License-Identifier: GPL-3.0-only
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package io.github.bytenomad47.a20.design

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.*
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

/**
 * Interactive design specimen. Synthetic data only; excluded from release APKs and app navigation.
 */
@Composable
internal fun SleepDashboardDesign(initialMetric: String? = null) {
    var selected by remember { mutableStateOf(LocalDate.of(2025, 11, 22)) }
    var calendar by remember { mutableStateOf(false) }
    var metric by remember { mutableStateOf(initialMetric) }
    val locale = LocalConfiguration.current.locales[0]
    val hasData =
        selected.dayOfMonth in 18..22 && selected.monthValue == 11 && selected.year == 2025
    if (calendar) {
        val date =
            rememberDatePickerState(
                initialSelectedDateMillis =
                    selected.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
            )
        DatePickerDialog(
            onDismissRequest = { calendar = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        date.selectedDateMillis?.let {
                            selected = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()
                        }
                        calendar = false
                    }
                ) {
                    Text("Choose date")
                }
            },
            dismissButton = { TextButton(onClick = { calendar = false }) { Text("Cancel") } },
        ) {
            DatePicker(date)
        }
    }
    metric?.let { key ->
        ModalBottomSheet(onDismissRequest = { metric = null }) {
            MetricDesign(key, selected)
        }
    }
    Column(
        Modifier.fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "Sleep",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.SemiBold,
            )
            TextButton(onClick = { calendar = true }) {
                Text(selected.format(DateTimeFormatter.ofPattern("MMM yyyy", locale)) + " ▾")
            }
        }
        Text(
            "Design preview · sample data",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val first = selected.minusDays(3)
            repeat(7) { index ->
                val day = first.plusDays(index.toLong())
                val chosen = day == selected
                Surface(
                    onClick = { selected = day },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(22.dp),
                    color =
                        if (chosen) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceContainer,
                ) {
                    Column(
                        Modifier.padding(vertical = 12.dp),
                        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                    ) {
                        Text(
                            day.format(DateTimeFormatter.ofPattern("EEEEE", locale)),
                            style = MaterialTheme.typography.labelMedium,
                        )
                        Text("${day.dayOfMonth}", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
        Text(
            selected.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)),
            style = MaterialTheme.typography.titleMedium,
        )
        if (!hasData) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("No sleep recorded", style = MaterialTheme.typography.titleLarge)
                    Text("Choose another date to explore the sample nights.")
                }
            }
        } else {
            Surface(
                onClick = { metric = "Sleep score" },
                shape = RoundedCornerShape(32.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    Modifier.padding(24.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Your night", style = MaterialTheme.typography.titleLarge)
                        Text("23:10 — 07:52", style = MaterialTheme.typography.titleMedium)
                        Text("Sleep score", style = MaterialTheme.typography.bodyMedium)
                    }
                    Box(
                        Modifier.size(104.dp),
                        contentAlignment = androidx.compose.ui.Alignment.Center,
                    ) {
                        val scheme = MaterialTheme.colorScheme
                        Canvas(Modifier.fillMaxSize()) {
                            drawArc(
                                scheme.primary.copy(alpha = .16f),
                                -90f,
                                360f,
                                false,
                                style = Stroke(9.dp.toPx()),
                            )
                            drawArc(
                                scheme.primary,
                                -90f,
                                302.4f,
                                false,
                                style =
                                    Stroke(
                                        9.dp.toPx(),
                                        cap = androidx.compose.ui.graphics.StrokeCap.Round,
                                    ),
                            )
                        }
                        Text(
                            "84",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Total sleep", "7h 28min", Modifier.weight(1f)) {
                    metric = "Total sleep"
                }
                MetricCard("In bed", "8h 42min", Modifier.weight(1f)) { metric = "In bed" }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Awakenings", "6", Modifier.weight(1f)) { metric = "Awakenings" }
                MetricCard("Efficiency", "86%", Modifier.weight(1f)) { metric = "Efficiency" }
            }
            TimelineDesign()
            Text(
                "Debugging tools",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Per-ear records and exports live here in the finished app.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(value, style = MaterialTheme.typography.titleLarge)
                Text(
                    "›",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

// Minutes total 522: Awake 74, Light 349, Deep 99. Entirely synthetic.
private val stages =
    listOf(
        10 to 0,
        52 to 1,
        42 to 2,
        81 to 1,
        12 to 0,
        73 to 1,
        57 to 2,
        73 to 1,
        24 to 0,
        70 to 1,
        28 to 0,
    )

private fun clock(minutes: Float): String =
    LocalTime.of(23, 10).plusMinutes(minutes.toLong()).toString()

@Composable
private fun TimelineDesign() {
    var movements by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableFloatStateOf(0f) }
    var inspected by remember { mutableFloatStateOf(225f) }
    val visible = 522f / zoom
    val scheme = MaterialTheme.colorScheme
    val colors = listOf(scheme.tertiary, scheme.secondary, scheme.primary)
    val labels = listOf("Awake", "Light", "Deep")
    val reports =
        listOf(15 to 1, 79 to 3, 142 to 2, 208 to 5, 279 to 1, 350 to 4, 419 to 2, 495 to 3)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            ) {
                Text("Your sleep", style = MaterialTheme.typography.titleLarge)
                Row {
                    IconButton(
                        onClick = {
                            zoom = 1f
                            offset = 0f
                        },
                        enabled = zoom > 1f,
                    ) {
                        Text("−")
                    }
                    IconButton(
                        onClick = {
                            zoom = 2f
                            offset = offset.coerceAtMost(261f)
                        },
                        enabled = zoom < 2f,
                    ) {
                        Text("+", color = scheme.primary)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!movements, { movements = false }, { Text("Stages") })
                FilterChip(movements, { movements = true }, { Text("Movement") })
            }
            var cursor = 0
            val stage =
                stages
                    .firstOrNull { (length, _) ->
                        cursor += length
                        inspected < cursor
                    }
                    ?.second ?: 0
            Text(
                if (movements) "${clock(inspected)} · movement reports"
                else "${clock(inspected)} · ${labels[stage]}",
                style = MaterialTheme.typography.labelLarge,
                color = scheme.primary,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!movements)
                    Column(
                        Modifier.width(44.dp).height(130.dp),
                        verticalArrangement = Arrangement.SpaceAround,
                    ) {
                        labels.forEachIndexed { i, label ->
                            Text(
                                label,
                                style = MaterialTheme.typography.labelSmall,
                                color = colors[i],
                            )
                        }
                    }
                Canvas(
                    Modifier.weight(1f)
                        .height(130.dp)
                        .semantics {
                            contentDescription =
                                "Sample sleep timeline. Drag to inspect a time; zoom to scroll."
                        }
                        .pointerInput(offset, visible) {
                            detectDragGestures { change, _ ->
                                inspected =
                                    (offset + change.position.x / size.width * visible).coerceIn(
                                        offset,
                                        offset + visible,
                                    )
                                change.consume()
                            }
                        }
                        .pointerInput(offset, visible) {
                            detectTapGestures {
                                inspected =
                                    (offset + it.x / size.width * visible).coerceIn(
                                        offset,
                                        offset + visible,
                                    )
                            }
                        }
                ) {
                    fun x(minute: Float) = (minute - offset) / visible * size.width
                    clipRect {
                        if (movements) {
                            reports.forEach { (minute, n) ->
                                drawRoundRect(
                                    scheme.primary,
                                    Offset(
                                        x(minute.toFloat()) - 3.dp.toPx(),
                                        size.height * (1f - n / 6f),
                                    ),
                                    Size(6.dp.toPx(), size.height * n / 6f),
                                    CornerRadius(3.dp.toPx()),
                                )
                            }
                        } else {
                            var start = 0f
                            stages.forEach { (length, i) ->
                                drawRoundRect(
                                    colors[i],
                                    Offset(x(start), size.height / 3 * i + 10.dp.toPx()),
                                    Size(length / visible * size.width, 20.dp.toPx()),
                                    CornerRadius(4.dp.toPx()),
                                )
                                start += length
                            }
                        }
                        drawLine(
                            scheme.onSurface.copy(alpha = .7f),
                            Offset(x(inspected), 0f),
                            Offset(x(inspected), size.height),
                            2.dp.toPx(),
                        )
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(start = if (movements) 0.dp else 52.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(clock(offset), style = MaterialTheme.typography.labelSmall)
                Text(clock(offset + visible), style = MaterialTheme.typography.labelSmall)
            }
            if (zoom > 1f)
                Slider(
                    value = offset,
                    onValueChange = {
                        offset = it
                        inspected = inspected.coerceIn(it, it + visible)
                    },
                    valueRange = 0f..522f - visible,
                    modifier = Modifier.semantics { contentDescription = "Scroll sleep timeline" },
                )
            if (!movements)
                Text(
                    "Awake 1h 14min  ·  Light 5h 49min  ·  Deep 1h 39min",
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant,
                )
        }
    }
}

@Composable
private fun MetricDesign(metric: String, date: LocalDate) {
    var days by remember { mutableIntStateOf(7) }
    var inspected by remember(metric, days) { mutableIntStateOf(days - 1) }
    val base =
        when (metric) {
            "Total sleep" -> 448
            "In bed" -> 522
            "Awakenings" -> 6
            "Efficiency" -> 86
            else -> 84
        }
    val scale =
        if (metric == "Total sleep" || metric == "In bed") 12
        else if (metric == "Awakenings") 1 else 3
    val values =
        remember(metric, days) {
            (0 until days).map { if (it % 9 == 0) null else base + (it % 5 - 2) * scale }
        }
    val available = values.filterNotNull()
    fun format(value: Double?) =
        when {
            value == null -> "—"
            metric == "Total sleep" || metric == "In bed" ->
                "${value.roundToInt()/60}h ${value.roundToInt()%60}min"
            metric == "Efficiency" -> "${value.roundToInt()}%"
            else -> "${value.roundToInt()}"
        }
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Text(metric, style = MaterialTheme.typography.headlineMedium)
        Text(
            "Design preview · sample data",
            style = MaterialTheme.typography.labelSmall,
            color = scheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(7, 30, 90).forEach { n ->
                FilterChip(days == n, { days = n }, { Text("${n}d") })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Average", style = MaterialTheme.typography.labelLarge)
                Text(
                    format(available.takeIf { it.isNotEmpty() }?.average()),
                    style = MaterialTheme.typography.headlineLarge,
                    color = scheme.primary,
                )
            }
            Column {
                Text("Nights recorded", style = MaterialTheme.typography.labelLarge)
                Text("${available.size} / $days", style = MaterialTheme.typography.headlineLarge)
            }
        }
        Text(
            "${date.minusDays((days-1-inspected).toLong())} · ${format(values[inspected]?.toDouble())}",
            style = MaterialTheme.typography.titleMedium,
        )
        Canvas(
            Modifier.fillMaxWidth()
                .height(160.dp)
                .semantics {
                    contentDescription = "Sample $metric history. Tap a bar to inspect its value."
                }
                .pointerInput(days) {
                    detectTapGestures {
                        inspected = (it.x / size.width * days).toInt().coerceIn(0, days - 1)
                    }
                }
        ) {
            val max = values.filterNotNull().maxOrNull()?.times(1.1f) ?: 1f
            values.forEachIndexed { i, value ->
                val step = size.width / days
                if (value != null) {
                    val height = value / max * size.height
                    drawRoundRect(
                        if (i == inspected) scheme.primary else scheme.primaryContainer,
                        Offset(i * step + step * .15f, size.height - height),
                        Size(step * .7f, height),
                        CornerRadius(4.dp.toPx()),
                    )
                } else
                    drawCircle(
                        scheme.outline,
                        2.dp.toPx(),
                        Offset((i + .5f) * step, size.height - 2.dp.toPx()),
                    )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "${date.minusDays((days-1).toLong())}",
                style = MaterialTheme.typography.labelSmall,
            )
            Text("$date", style = MaterialTheme.typography.labelSmall)
        }
        Text(
            "Only nights with a reading contribute to the average.",
            style = MaterialTheme.typography.bodySmall,
            color = scheme.onSurfaceVariant,
        )
    }
}
