// SPDX-License-Identifier: GPL-3.0-only
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)

package io.github.bytenomad47.a20.sleep

import android.app.Application
import android.graphics.Bitmap
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import io.github.bytenomad47.a20.SleepTimelineDetails
import io.github.bytenomad47.a20.protocol.*
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.time.Instant
import org.junit.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class SleepTimelineUiTest {
    @get:Rule val ui = createComposeRule()

    @Test
    fun partialStagesAndReportTimeMovementsInLightTheme() {
        show(false)
        ui.onNodeWithText("Recorded stages").assertExists()
        ui.onNodeWithText("Unknown").assertExists()
        ui.onNodeWithText("Unknown marks missing", substring = true).assertExists()
        screenshot("light-stages")
        ui.onNodeWithText("Movement", useUnmergedTree = true).performClick()
        ui.onNodeWithText("11 movements in received reports").assertExists()
        ui.onNodeWithText("They can include movements before this interval", substring = true)
            .assertExists()
        screenshot("light-movement")
    }

    @Test
    fun partialStagesAndReportTimeMovementsInDarkTheme() {
        show(true)
        ui.onNodeWithText("Recorded stages").assertExists()
        screenshot("dark-stages")
        ui.onNodeWithText("Movement", useUnmergedTree = true).performClick()
        ui.onNodeWithText("11 movements in received reports").assertExists()
        screenshot("dark-movement")
    }

    private fun show(dark: Boolean) {
        val start = Instant.parse("2025-04-03T00:00:00Z")
        val session = SleepSession(0, start, start.plusSeconds(3600), 82)
        val records =
            listOf(Triple(600, 1, 0), Triple(1200, 2, 4), Triple(2400, 3, 7)).map {
                (offset, stage, turns) ->
                val b =
                    ByteBuffer.allocate(6)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .putInt(start.epochSecond.toInt() + offset)
                        .put(stage.toByte())
                        .put(turns.toByte())
                        .array()
                SleepRecord(
                    SleepRecordKind.EVENTS,
                    0,
                    b.joinToString("") { "%02x".format(it.toInt() and 255) },
                )
            }
        val timeline =
            SleepTimelines.build(session, records, SleepTimelines.linksFromSnapshot(records))
        ui.setContent {
            MaterialExpressiveTheme(
                colorScheme = if (dark) darkColorScheme() else lightColorScheme()
            ) {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Text("Sleep history", style = MaterialTheme.typography.headlineLarge)
                        Text(
                            "Left earbud · timeline preview",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Card {
                            Column(Modifier.padding(20.dp)) { SleepTimelineDetails(timeline) }
                        }
                    }
                }
            }
        }
    }

    private fun screenshot(name: String) {
        val out = File("build/screenshots/sleep-timeline-$name-synthetic.png")
        out.parentFile?.mkdirs()
        out.outputStream().use {
            ui.onRoot()
                .captureToImage()
                .asAndroidBitmap()
                .compress(Bitmap.CompressFormat.PNG, 100, it)
        }
    }
}
