// SPDX-License-Identifier: GPL-3.0-only
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)

package io.github.bytenomad47.a20.design

import android.app.Application
import android.graphics.Bitmap
import androidx.compose.material3.*
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import java.io.File
import org.junit.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class SleepDashboardDesignTest {
    @get:Rule val ui = createComposeRule()

    @Test fun lightDashboard() = dashboard(false)

    @Test fun darkDashboard() = dashboard(true)

    private fun dashboard(dark: Boolean) {
        ui.setContent {
            MaterialExpressiveTheme(
                colorScheme = if (dark) darkColorScheme() else lightColorScheme()
            ) {
                Surface { SleepDashboardDesign() }
            }
        }
        ui.onNodeWithText("Design preview · sample data").assertExists()
        capture(if (dark) "dark" else "light")
        ui.onNodeWithText("Total sleep").performClick()
        ui.onNodeWithText("Average").assertExists()
        capture(if (dark) "dark-metric" else "light-metric")
        ui.onNodeWithText("30d").performClick()
        ui.onNodeWithText("26 / 30").assertExists()
    }

    private fun capture(name: String) {
        val p = File("build/screenshots/nightly-design-$name.png")
        p.parentFile?.mkdirs()
        p.outputStream().use {
            ui.onAllNodes(isRoot(), useUnmergedTree = true)
                .onLast()
                .captureToImage()
                .asAndroidBitmap()
                .compress(Bitmap.CompressFormat.PNG, 100, it)
        }
    }
}
