// SPDX-License-Identifier: GPL-3.0-only
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)

package io.github.bytenomad47.a20.sleep

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import io.github.bytenomad47.a20.*
import io.github.bytenomad47.a20.protocol.*
import java.io.File
import java.time.*
import java.util.Locale
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.*

private fun sampleReport(day: Int = 3, complete: Boolean = true, score: Int? = 82): SleepReport {
    val start = Instant.parse("2025-04-0${day}T00:00:00Z")
    val end = start.plusSeconds(8 * 3600)
    return SleepReport(
        SleepMetricWindow(start, end),
        listOf(SleepSession(0, start, end, score)),
        listOf(
            SleepStageSpan(start, start.plusSeconds(3600), SleepStage.AWAKE),
            SleepStageSpan(start.plusSeconds(3600), start.plusSeconds(6 * 3600), SleepStage.LIGHT),
            SleepStageSpan(
                start.plusSeconds(6 * 3600),
                end,
                if (complete) SleepStage.DEEP else SleepStage.UNKNOWN,
            ),
        ),
        Duration.ZERO,
        false,
    )
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class SleepDashboardUiTest {
    @get:Rule val ui = createComposeRule()

    @Test
    fun dashboardUsesRealModelAndOpensMetricHistory() {
        show(false)
        ui.onNodeWithText("7h 0min").assertExists()
        ui.onNodeWithText("82").assertExists()
        ui.onNodeWithContentDescription("Sleep score 82 out of 100").assertExists()
        ui.onNodeWithText("Total sleep").performClick()
        ui.onNodeWithText("Average").assertExists()
        ui.onNodeWithText("Average")
            .onParent()
            .onChildren()
            .filter(hasText("7h 0min"))
            .assertCountEquals(1)
        ui.onNodeWithText("1 / 7").assertExists()
        ui.onNodeWithText("30d").performClick()
        ui.onNodeWithText("1 / 30").assertExists()
    }

    @Test
    fun unknownIntervalsWithholdTotalsAndAllowChoosingAnEmptyDate() {
        show(false, complete = false)
        ui.onNodeWithText("Sleep totals stay unavailable", substring = true).assertExists()
        ui.onNodeWithText("4", useUnmergedTree = true).performClick()
        ui.onNodeWithText("No saved session").assertExists()
        ui.onNodeWithText("Your night").assertDoesNotExist()
    }

    @Test
    fun stageChartSupportsInspectionAndZoom() {
        show(false)
        ui.onNodeWithText("08:00").assertExists()
        ui.onNodeWithContentDescription(
                "Sleep stages chart. Drag to inspect. Unknown intervals are gray."
            )
            .performScrollTo()
            .performTouchInput { click(center) }
        ui.onNodeWithText("· Light", substring = true).assertExists()
        ui.onNodeWithText("2×").performScrollTo().performClick()
        ui.onNodeWithContentDescription("Scroll timeline").performScrollTo().performSemanticsAction(
            SemanticsActions.SetProgress
        ) {
            it(1f)
        }
        ui.onNodeWithText("04:00").assertExists()
        ui.onNodeWithText("08:00").assertExists()
    }

    @Test
    fun darkDashboardRendersFromTheSameModel() {
        show(true)
    }

    private fun show(dark: Boolean, complete: Boolean = true) {
        ui.setContent {
            MaterialExpressiveTheme(
                colorScheme = if (dark) darkColorScheme() else lightColorScheme()
            ) {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)
                    ) {
                        Text("Sleep history", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.height(16.dp))
                        SleepDashboardContent(listOf(sampleReport(complete = complete)))
                    }
                }
            }
        }
        val output =
            File("build/screenshots/sleep-dashboard-${if(dark)"dark" else "light"}-synthetic.png")
        output.parentFile?.mkdirs()
        output.outputStream().use {
            ui.onRoot()
                .captureToImage()
                .asAndroidBitmap()
                .compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
        }
    }
}

class SleepMetricHistoryTest {
    @Test
    fun missingDaysAndPartialTotalsAreExcludedFromAverages() {
        val report = sampleReport()
        val partial = sampleReport(2, false)
        val values =
            sleepMetricDays(
                listOf(report, partial),
                LocalDate.of(2025, 4, 3),
                7,
                ZoneOffset.UTC,
                SleepDashboardMetric.SLEEP,
            )
        assertEquals(7, values.size)
        assertEquals(listOf(420.0), values.mapNotNull { it.value })
        assertEquals(420.0, values.mapNotNull { it.value }.average(), 0.0)
        assertNull(values[5].value)
    }

    @Test
    fun sameDaySessionsUseDeclaredLongestSessionInsteadOfAddingOverlappingMetrics() {
        val main = sampleReport()
        val short =
            main.copy(
                window = SleepMetricWindow(main.window.start, main.window.start.plusSeconds(3600))
            )
        val a =
            sleepMetricDays(
                listOf(short, main),
                LocalDate.of(2025, 4, 3),
                7,
                ZoneOffset.UTC,
                SleepDashboardMetric.RECORDED,
            )
        val b =
            sleepMetricDays(
                listOf(main, short),
                LocalDate.of(2025, 4, 3),
                7,
                ZoneOffset.UTC,
                SleepDashboardMetric.RECORDED,
            )
        assertEquals(a, b)
        assertEquals(480.0, a.last().value!!, 0.0)
    }

    @Test
    fun timezoneDeterminesDateAndDstClockLabelsDisambiguateTheRepeatedHour() {
        val paris = ZoneId.of("Europe/Paris")
        val start = Instant.parse("2025-10-26T00:30:00Z")
        val end = Instant.parse("2025-10-26T01:30:00Z")
        assertEquals("02:30 +02:00 – 02:30 +01:00", sleepReportClock(start, end, paris, Locale.US))
        val sample =
            sampleReport().let {
                it.copy(
                    window = SleepMetricWindow(it.window.start.minusSeconds(3600), it.window.start)
                )
            }
        val values =
            sleepMetricDays(
                listOf(sample),
                LocalDate.of(2025, 4, 2),
                1,
                ZoneId.of("America/New_York"),
                SleepDashboardMetric.RECORDED,
            )
        assertEquals(60.0, values.single().value!!, 0.0)
    }
}
