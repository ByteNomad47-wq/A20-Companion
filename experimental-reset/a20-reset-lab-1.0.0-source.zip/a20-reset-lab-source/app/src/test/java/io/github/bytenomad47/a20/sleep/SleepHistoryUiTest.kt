// SPDX-License-Identifier: GPL-3.0-only
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3ExpressiveApi::class)

package io.github.bytenomad47.a20.sleep

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import io.github.bytenomad47.a20.SleepHistoryPage
import io.github.bytenomad47.a20.SleepSessionsView
import io.github.bytenomad47.a20.device.CompanionRepository
import io.github.bytenomad47.a20.protocol.SleepSession
import java.io.File
import java.time.Instant
import kotlinx.coroutines.cancel
import org.junit.*
import org.junit.runner.RunWith
import org.robolectric.*
import org.robolectric.annotation.*

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], application = Application::class, qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class SleepHistoryUiTest {
    @get:Rule val ui = createComposeRule()

    @Test
    fun emptyPreviewRequiresExplicitSyncAndKeepsDebugExportsOptional() {
        val context = RuntimeEnvironment.getApplication()
        val repo = CompanionRepository(context)
        val controller = SleepHistoryController(context, repo)
        try {
            ui.setContent {
                MaterialExpressiveTheme {
                    Surface(Modifier.fillMaxSize()) {
                        SleepHistoryPage(controller, null, false, {}, {})
                    }
                }
            }
            ui.onNodeWithText("Sleep history").assertExists()
            ui.onNodeWithText("Your nights").assertExists()
            ui.onNodeWithText("Sync sleep records").assertIsNotEnabled()
            ui.onNodeWithText("Choose your A20 on Home first.").assertExists()
            ui.onNodeWithText("Debugging tools").performScrollTo().performClick()
            ui.onNodeWithText("Export sleep report").performScrollTo().assertIsNotEnabled()
        } finally {
            repo.scope.cancel()
        }
    }

    @Test
    fun savedSessionsStaySeparateAndCanBeFilteredByEar() {
        showSessions(false)
        ui.onNodeWithText("Left earbud").assertExists()
        ui.onNodeWithText("Right earbud").assertExists()
        ui.onNodeWithText("82 / 100").assertExists()
        ui.onNodeWithText("Unavailable").assertExists()
        ui.onNodeWithText("Recorded interval · 8h 0min").assertExists()
        ui.onNodeWithText("Right", useUnmergedTree = true).performClick()
        ui.onNodeWithText("Left earbud").assertDoesNotExist()
        ui.onNodeWithText("Right earbud").assertExists()
        ui.onNodeWithText("Left", useUnmergedTree = true).performClick()
        ui.onNodeWithText("Right earbud").assertDoesNotExist()
        ui.onNodeWithText("Left earbud").assertExists()
    }

    @Test
    fun sessionPreviewInDarkTheme() {
        showSessions(true)
        ui.onNodeWithText("82 / 100").assertExists()
    }

    private fun showSessions(dark: Boolean) {
        val sessions =
            listOf(
                SleepSession(
                    0,
                    Instant.parse("2025-04-02T22:00:00Z"),
                    Instant.parse("2025-04-03T06:00:00Z"),
                    82,
                ),
                SleepSession(
                    1,
                    Instant.parse("2025-04-02T22:10:00Z"),
                    Instant.parse("2025-04-03T05:50:00Z"),
                    null,
                ),
            )
        ui.setContent {
            MaterialExpressiveTheme(
                colorScheme = if (dark) darkColorScheme() else lightColorScheme()
            ) {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        Text("Sleep history", style = MaterialTheme.typography.headlineLarge)
                        SleepSessionsView(sessions)
                    }
                }
            }
        }
        val out =
            File("build/screenshots/sleep-sessions-${if(dark) "dark" else "light"}-synthetic.png")
        out.parentFile.mkdirs()
        out.outputStream().use {
            ui.onRoot()
                .captureToImage()
                .asAndroidBitmap()
                .compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
        }
    }
}
