// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.github.bytenomad47.a20.protocol.SleepEventLink
import io.github.bytenomad47.a20.protocol.SleepRecord
import io.github.bytenomad47.a20.protocol.SleepRecordKind
import io.github.bytenomad47.a20.protocol.SleepReports
import io.github.bytenomad47.a20.protocol.SleepSession
import io.github.bytenomad47.a20.protocol.SleepSessions
import io.github.bytenomad47.a20.protocol.SleepTimelines
import io.github.bytenomad47.a20.sleep.SleepHistoryController
import java.text.DateFormat
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch

@Composable
internal fun SleepHistoryPage(
    controller: SleepHistoryController,
    selected: String?,
    busy: Boolean,
    onBack: () -> Unit,
    onExport: (String) -> Unit,
) {
    val state by controller.state.collectAsStateWithLifecycle()
    val sessions = remember(state.records) { SleepSessions.decode(state.records) }
    val reports =
        remember(state.records, state.eventLinks) {
            SleepReports.build(state.records, state.eventLinks)
        }
    val scope = rememberCoroutineScope()
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, scope) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) scope.coroutineContext.cancelChildren()
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            scope.coroutineContext.cancelChildren()
        }
    }
    var details by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(selected) { controller.load() }
    if (confirmDelete)
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete local sleep history?") },
            text = {
                Text(
                    "Delete this pair’s imported sleep records from Companion. Records stored on the earbuds are unchanged."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmDelete = false
                        scope.launch { controller.deleteLocal() }
                    }
                ) {
                    Text("Delete")
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    Column(
        Modifier.fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        TextButton(onClick = onBack) { Text("‹ Back") }
        Text(
            "Sleep history",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.SemiBold,
        )
        SleepDashboardContent(reports)
        Button(
            onClick = { scope.launch { controller.sync() } },
            enabled = selected != null && !busy && !state.loading,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(if (state.loading) "Reading sleep history…" else "Sync sleep records")
        }
        if (state.loading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (selected == null) Text("Choose your A20 on Home first.")
        state.message?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (state.syncedAt > 0) {
            Text(
                "Last sync: ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(state.syncedAt))}",
                style = MaterialTheme.typography.bodySmall,
            )
        } else
            Text(
                "Sync after a night of use to check for saved records. Recording must already be enabled in Soundcore; this preview does not change that setting."
            )
        TextButton(onClick = { details = !details }) {
            Text(if (details) "Hide debugging tools" else "Debugging tools")
        }
        if (details) {
            Text("Original per-ear records", style = MaterialTheme.typography.titleMedium)
            SleepSessionsView(sessions, state.records, state.eventLinks)
            for (source in 0..1) {
                Text(
                    "${if (source == 0) "Left" else "Right"}: ${state.records.count { it.source == source && it.kind == SleepRecordKind.EVENTS }} event records · ${state.records.count { it.source == source && it.kind == SleepRecordKind.SUMMARIES }} summary records",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Text(
                "Original A6611 · firmware 01.57. Reads only; no clock changes, recording toggle or automatic background syncing. Up to 3,000 unique records are retained per pair.",
                style = MaterialTheme.typography.bodySmall,
            )
            if (state.sources.isNotEmpty())
                Text(
                    "Sources received: ${state.sources}",
                    style = MaterialTheme.typography.bodySmall,
                )
            Text(
                "Exports contain personal sleep records. Review them before sharing.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedButton(
                onClick = { confirmDelete = true },
                enabled = state.syncedAt > 0 && !state.loading && !busy,
            ) {
                Text("Delete local sleep history")
            }
            OutlinedButton(
                onClick = { onExport(controller.export()) },
                enabled = (state.syncedAt > 0 || state.attempted) && !state.loading,
            ) {
                Text("Export sleep report")
            }
        }
    }
}

@Composable
internal fun SleepSessionsView(
    sessions: List<SleepSession>,
    records: List<SleepRecord> = emptyList(),
    links: List<SleepEventLink> = emptyList(),
) {
    var source by remember { mutableIntStateOf(-1) }
    var limit by remember(sessions, source) { mutableIntStateOf(20) }
    var expanded by
        remember(sessions, source) { mutableStateOf<Pair<Int, java.time.Instant>?>(null) }
    val filtered =
        remember(sessions, source) { sessions.filter { source == -1 || it.source == source } }
    val zone = ZoneId.systemDefault()
    val locale = LocalConfiguration.current.locales[0]
    val date = DateTimeFormatter.ofPattern("EEE, d MMM yyyy", locale)
    val time = DateTimeFormatter.ofPattern("HH:mm", locale)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(-1 to "Both", 0 to "Left", 1 to "Right").forEach { (value, label) ->
            FilterChip(
                selected = source == value,
                onClick = { source = value },
                label = { Text(label) },
                modifier = Modifier.weight(1f),
            )
        }
    }
    Text("Times in ${zone.id}", style = MaterialTheme.typography.bodySmall)
    if (filtered.isEmpty()) {
        Text(
            "No saved sleep sessions imported for ${if (source == 0) "the left earbud" else if (source == 1) "the right earbud" else "this pair"} yet."
        )
        return
    }
    var previousDate: java.time.LocalDate? = null
    for (session in filtered.take(limit)) {
        val start = session.start.atZone(zone)
        val end = session.end.atZone(zone)
        if (end.toLocalDate() != previousDate) {
            Text(end.format(date), style = MaterialTheme.typography.titleMedium)
            previousDate = end.toLocalDate()
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (session.source == 0) "Left earbud" else "Right earbud",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
                // Include offset when clocks change within a session, so repeated hours are clear.
                val clock =
                    if (start.offset != end.offset) DateTimeFormatter.ofPattern("HH:mm XXX", locale)
                    else time
                Text(
                    "${start.format(clock)} – ${end.format(clock)}",
                    style = MaterialTheme.typography.titleLarge,
                )
                if (start.toLocalDate() != end.toLocalDate())
                    Text(
                        "Started ${start.format(date)}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                val minutes = session.interval.toMinutes()
                Text(
                    "Recorded interval · ${minutes / 60}h ${minutes % 60}min",
                    style = MaterialTheme.typography.bodyMedium,
                )
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Earbud score", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        session.score?.let { "$it / 100" } ?: "Unavailable",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                val key = session.source to session.start
                TextButton(onClick = { expanded = if (expanded == key) null else key }) {
                    Text(if (expanded == key) "Hide timeline" else "Show timeline")
                }
                if (expanded == key) {
                    val timeline =
                        remember(session, records, links) {
                            SleepTimelines.build(session, records, links)
                        }
                    SleepTimelineDetails(timeline)
                }
            }
        }
    }
    if (filtered.size > limit)
        OutlinedButton(onClick = { limit += 20 }, modifier = Modifier.fillMaxWidth()) {
            Text("Show older sessions")
        }
}
