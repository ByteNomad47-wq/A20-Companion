// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import io.github.bytenomad47.a20.protocol.*
import java.time.Duration
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
internal fun SleepTimelineDetails(timeline: SleepTimeline) {
    var movement by
        remember(timeline.session.source, timeline.session.start) { mutableStateOf(false) }
    val scheme = MaterialTheme.colorScheme
    val colors =
        mapOf(
            SleepStage.AWAKE to scheme.tertiary,
            SleepStage.LIGHT to scheme.secondary,
            SleepStage.DEEP to scheme.primary,
            SleepStage.UNKNOWN to scheme.outline,
        )
    val labels =
        mapOf(
            SleepStage.AWAKE to "Awake",
            SleepStage.LIGHT to "Light",
            SleepStage.DEEP to "Deep",
            SleepStage.UNKNOWN to "Unknown",
        )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(!movement, { movement = false }, { Text("Stages") }, Modifier.weight(1f))
            FilterChip(movement, { movement = true }, { Text("Movement") }, Modifier.weight(1f))
        }
        val seconds = timeline.session.interval.seconds.toDouble().coerceAtLeast(1.0)
        fun fraction(time: java.time.Instant): Float =
            (Duration.between(timeline.session.start, time).seconds / seconds)
                .toFloat()
                .coerceIn(0f, 1f)
        if (!movement) {
            Text("Recorded stages", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(
                    Modifier.width(58.dp).height(152.dp),
                    verticalArrangement = Arrangement.SpaceAround,
                ) {
                    SleepStage.entries.forEach { stage ->
                        Text(
                            labels.getValue(stage),
                            color = colors.getValue(stage),
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                }
                val description =
                    "Per-ear stage timeline. " +
                        SleepStage.entries.joinToString { stage ->
                            "${labels.getValue(stage)}: ${timeline.points.count { it.stage == stage }} received transitions"
                        } +
                        if (timeline.partial) ". Some stage history is unknown." else "."
                Canvas(
                    Modifier.weight(1f).height(152.dp).semantics {
                        contentDescription = description
                    }
                ) {
                    val row = size.height / 4
                    for (i in 0..3) drawLine(
                        scheme.outlineVariant,
                        Offset(0f, row * (i + .5f)),
                        Offset(size.width, row * (i + .5f)),
                    )
                    clipRect {
                        timeline.spans.forEach { span ->
                            val x = fraction(span.start) * size.width
                            val width =
                                ((fraction(span.end) - fraction(span.start)) * size.width)
                                    .coerceAtLeast(1f)
                            drawRoundRect(
                                colors
                                    .getValue(span.stage)
                                    .copy(
                                        alpha = if (span.stage == SleepStage.UNKNOWN) .35f else .85f
                                    ),
                                Offset(x, span.stage.ordinal * row + row * .3f),
                                Size(width, row * .4f),
                                CornerRadius(3.dp.toPx()),
                            )
                        }
                        timeline.points.forEach { point ->
                            drawCircle(
                                colors.getValue(point.stage),
                                2.5.dp.toPx(),
                                Offset(
                                    fraction(point.time) * size.width,
                                    point.stage.ordinal * row + row * .5f,
                                ),
                            )
                        }
                    }
                }
            }
            TimelineTimes(timeline, Modifier.padding(start = 66.dp))
            Text(
                if (timeline.partial)
                    "Unknown marks missing or unrecognised stage history. Dots are received changes; sync again to fill any gaps still stored on the earbuds."
                else "Device-reported stages within this earbud’s recorded interval.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
            )
        } else {
            val reports = timeline.points.filter { it.movements != null }
            Text(
                when {
                    timeline.points.isEmpty() -> "No movement reports in this interval"
                    reports.size != timeline.points.size ->
                        "Movement reports · some counts unavailable"
                    else -> "${timeline.reportedMovements} movements in received reports"
                },
                style = MaterialTheme.typography.titleSmall,
            )
            if (timeline.points.isNotEmpty()) {
                val maximum = reports.maxOfOrNull { it.movements!! }?.coerceAtLeast(1) ?: 1
                Canvas(
                    Modifier.fillMaxWidth().height(112.dp).semantics {
                        contentDescription =
                            "Movement counts at report times; ${reports.size} reports with known counts. Exact movement times are unavailable."
                    }
                ) {
                    drawLine(
                        scheme.outlineVariant,
                        Offset(0f, size.height),
                        Offset(size.width, size.height),
                    )
                    clipRect {
                        reports
                            .filter { it.movements!! > 0 }
                            .forEach { point ->
                                val height =
                                    point.movements!! / maximum.toFloat() *
                                        (size.height - 4.dp.toPx())
                                drawRoundRect(
                                    scheme.primary,
                                    Offset(
                                        fraction(point.time) * size.width - 2.dp.toPx(),
                                        size.height - height,
                                    ),
                                    Size(4.dp.toPx(), height),
                                    CornerRadius(2.dp.toPx()),
                                )
                            }
                    }
                }
                TimelineTimes(timeline)
            }
            Text(
                "Counts are grouped at report times. They can include movements before this interval and omit overwritten reports.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
            )
        }
        Text(
            "Each earbud is shown separately; these charts do not reproduce Soundcore’s combined analysis.",
            style = MaterialTheme.typography.bodySmall,
            color = scheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun TimelineTimes(timeline: SleepTimeline, modifier: Modifier = Modifier) {
    val zone = ZoneId.systemDefault()
    val start = timeline.session.start.atZone(zone)
    val end = timeline.session.end.atZone(zone)
    val locale = LocalConfiguration.current.locales[0]
    val clock =
        DateTimeFormatter.ofPattern(
            if (start.offset != end.offset) "HH:mm XXX" else "HH:mm",
            locale,
        )
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(start.format(clock), style = MaterialTheme.typography.labelSmall)
        Text(end.format(clock), style = MaterialTheme.typography.labelSmall)
    }
}
