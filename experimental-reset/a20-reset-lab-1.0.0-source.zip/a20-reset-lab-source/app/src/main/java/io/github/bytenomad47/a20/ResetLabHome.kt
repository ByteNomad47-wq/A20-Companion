// SPDX-License-Identifier: GPL-3.0-only
package io.github.bytenomad47.a20

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import io.github.bytenomad47.a20.device.CompanionState

@Composable
internal fun ResetLabHome(state: CompanionState, choose: () -> Unit, refresh: () -> Unit, repair: () -> Unit) {
    Column(Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text("A20 Reset Lab", style = MaterialTheme.typography.headlineLarge)
        Text("Experimental · original A6611 only", style = MaterialTheme.typography.titleMedium)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Text("This separate app removes the firmware-version gate for charging-record resets. Only 01.57 has been examined; 01.58 compatibility is unverified. It does not install or downgrade firmware, and it cannot restore erased records.", Modifier.padding(20.dp))
        }
        Text("1. Pair the original Sleep A20 in Android Bluetooth settings.\n2. Close Soundcore and Companion to release their control connections.\n3. Choose the A20 below. On the reset page, keep only the selected earbud out of the closed case.\n4. Review the warning before resetting. Export the report afterwards.")
        FilledTonalButton(onClick = choose, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) {
            Text(state.selectedName ?: "Choose your A20")
        }
        OutlinedButton(onClick = refresh, enabled = state.selectedName != null && !state.busy, modifier = Modifier.fillMaxWidth()) { Text("Read connection status") }
        Text(state.message)
        Button(onClick = repair, enabled = state.selectedName != null && !state.busy, modifier = Modifier.fillMaxWidth()) { Text("Open experimental reset") }
        Text("Confirm the A6611 model on the case/box. Device-name filtering is not independent proof of hardware identity. No reset runs when opening the app or choosing a device.", style = MaterialTheme.typography.bodySmall)
    }
}
