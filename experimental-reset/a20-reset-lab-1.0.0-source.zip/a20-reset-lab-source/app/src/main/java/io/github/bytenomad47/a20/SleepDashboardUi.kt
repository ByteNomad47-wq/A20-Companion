// SPDX-License-Identifier: GPL-3.0-only
@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package io.github.bytenomad47.a20

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import io.github.bytenomad47.a20.protocol.*
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

internal enum class SleepDashboardMetric(val label: String) {
    SCORE("Sleep score"),
    RECORDED("Recorded interval"),
    SLEEP("Total sleep"),
    DEEP("Deep sleep"),
    EFFICIENCY("Efficiency");

    fun value(report: SleepReport): Double? =
        when (this) {
            SCORE -> report.score?.toDouble()
            RECORDED -> report.window.duration.seconds / 60.0
            SLEEP -> report.totals.totalSleep?.seconds?.div(60.0)
            DEEP -> if (report.totals.complete) report.totals.deep.seconds / 60.0 else null
            EFFICIENCY -> report.totals.efficiencyPercent?.toDouble()
        }

    fun format(value: Double?): String =
        when {
            value == null -> "—"
            this == SCORE -> "${value.roundToInt()} / 100"
            this == EFFICIENCY -> "${value.roundToInt()}%"
            else -> "${value.toLong() / 60}h ${value.toLong() % 60}min"
        }
}

internal data class SleepMetricDay(val date: LocalDate, val value: Double?)

/**
 * Comparable daily reference: longest recorded session, not the sum of potentially overlapping
 * reports.
 */
internal fun sleepMetricDays(
    reports: List<SleepReport>,
    end: LocalDate,
    days: Int,
    zone: ZoneId,
    metric: SleepDashboardMetric,
): List<SleepMetricDay> {
    require(days in 1..90)
    val byDay = reports.groupBy { it.window.end.atZone(zone).toLocalDate() }
    return (0 until days).map { index ->
        val date = end.minusDays((days - index - 1).toLong())
        val report =
            byDay[date]
                ?.sortedWith(
                    compareByDescending<SleepReport> { it.window.duration }
                        .thenByDescending { it.window.end }
                )
                ?.firstOrNull()
        SleepMetricDay(date, report?.let { metric.value(it) })
    }
}

@Composable
internal fun SleepDashboardContent(reports: List<SleepReport>) {
    val zone = ZoneId.systemDefault()
    val locale = LocalConfiguration.current.locales[0]
    val latest =
        reports.maxOfOrNull { it.window.end }?.atZone(zone)?.toLocalDate() ?: LocalDate.now(zone)
    var dayKey by rememberSaveable { mutableStateOf<Long?>(null) }
    val day = dayKey?.let(LocalDate::ofEpochDay) ?: latest
    var selectedStart by rememberSaveable(day) { mutableStateOf<Long?>(null) }
    val choices = reports.filter { it.window.end.atZone(zone).toLocalDate() == day }
    val chosen =
        choices.firstOrNull { it.window.start.epochSecond == selectedStart }
            ?: choices.maxWithOrNull(
                compareBy<SleepReport> { it.window.duration }.thenBy { it.window.end }
            )
    var calendar by remember { mutableStateOf(false) }
    var metric by remember { mutableStateOf<SleepDashboardMetric?>(null) }
    if (calendar) {
        val picker =
            rememberDatePickerState(
                initialSelectedDateMillis =
                    day.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
            )
        DatePickerDialog(
            onDismissRequest = { calendar = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        picker.selectedDateMillis?.let {
                            dayKey =
                                Instant.ofEpochMilli(it)
                                    .atZone(ZoneOffset.UTC)
                                    .toLocalDate()
                                    .toEpochDay()
                        }
                        calendar = false
                    }
                ) {
                    Text("Choose date")
                }
            },
            dismissButton = { TextButton(onClick = { calendar = false }) { Text("Cancel") } },
        ) {
            DatePicker(picker)
        }
    }
    metric?.let { selected ->
        ModalBottomSheet(onDismissRequest = { metric = null }) {
            SleepMetricHistory(reports, day, zone, selected)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Your nights", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { calendar = true }) {
                Text(day.format(DateTimeFormatter.ofPattern("MMM yyyy", locale)) + " ▾")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(7) { index ->
                val date = day.minusDays(3).plusDays(index.toLong())
                Surface(
                    onClick = { dayKey = date.toEpochDay() },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(22.dp),
                    color =
                        if (date == day) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceContainer,
                ) {
                    Column(
                        Modifier.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            date.format(DateTimeFormatter.ofPattern("EEEEE", locale)),
                            style = MaterialTheme.typography.labelSmall,
                        )
                        Text("${date.dayOfMonth}", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
        Text(
            day.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)),
            style = MaterialTheme.typography.titleMedium,
        )
        if (chosen == null) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("No saved session", style = MaterialTheme.typography.titleLarge)
                    Text("Choose another date or sync the records still stored on your earbuds.")
                }
            }
        } else {
            if (choices.size > 1) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    choices.forEach { report ->
                        FilterChip(
                            report == chosen,
                            { selectedStart = report.window.start.epochSecond },
                            {
                                Text(
                                    sleepReportClock(
                                        report.window.start,
                                        report.window.end,
                                        zone,
                                        locale,
                                    )
                                )
                            },
                        )
                    }
                }
            }
            Card(
                onClick = { metric = SleepDashboardMetric.SCORE },
                modifier = Modifier.fillMaxWidth(),
                colors =
                    CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                shape = RoundedCornerShape(32.dp),
            ) {
                Row(
                    Modifier.padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Your night", style = MaterialTheme.typography.titleLarge)
                        Text(
                            sleepReportClock(chosen.window.start, chosen.window.end, zone, locale),
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text("Sleep score", style = MaterialTheme.typography.labelLarge)
                    }
                    Box(
                        Modifier.size(104.dp).semantics {
                            contentDescription =
                                chosen.score?.let { "Sleep score $it out of 100" }
                                    ?: "Sleep score unavailable"
                        },
                        contentAlignment = Alignment.Center,
                    ) {
                        val scheme = MaterialTheme.colorScheme
                        Canvas(Modifier.fillMaxSize()) {
                            drawArc(
                                scheme.primary.copy(alpha = .16f),
                                -90f,
                                360f,
                                false,
                                style = Stroke(9.dp.toPx()),
                            )
                            chosen.score?.let { value ->
                                drawArc(
                                    scheme.primary,
                                    -90f,
                                    value.coerceIn(0, 100) * 3.6f,
                                    false,
                                    style = Stroke(9.dp.toPx(), cap = StrokeCap.Round),
                                )
                            }
                        }
                        Text(
                            chosen.score?.toString() ?: "—",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
            for (pair in
                listOf(
                    SleepDashboardMetric.SLEEP to SleepDashboardMetric.RECORDED,
                    SleepDashboardMetric.DEEP to SleepDashboardMetric.EFFICIENCY,
                )) {
                Row(
                    Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    listOf(pair.first, pair.second).forEach { key ->
                        Card(
                            onClick = { metric = key },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                        ) {
                            Column(
                                Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Text(key.label, style = MaterialTheme.typography.labelLarge)
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        key.format(key.value(chosen)),
                                        style = MaterialTheme.typography.titleLarge,
                                    )
                                    Text(
                                        "›",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                        }
                    }
                }
            }
            if (chosen.score == null)
                Text(
                    "Sleep scores are missing or differ between sources.",
                    style = MaterialTheme.typography.bodySmall,
                )
            if (chosen.ambiguous || !chosen.totals.complete) {
                Text(
                    if (chosen.ambiguous)
                        "Session boundaries overlap ambiguously. Open debugging tools to inspect the original records."
                    else
                        "Some stage history is missing or differs between earbuds. Sleep totals stay unavailable for this session.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            SleepReportChart(chosen, zone, locale)
            Text(
                "Local preview · device-reported stages. Recorded interval includes awake time. Soundcore’s combined analysis may differ.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

internal fun sleepReportClock(start: Instant, end: Instant, zone: ZoneId, locale: Locale): String {
    val a = start.atZone(zone)
    val b = end.atZone(zone)
    val pattern = if (a.offset != b.offset) "HH:mm XXX" else "HH:mm"
    val time = DateTimeFormatter.ofPattern(pattern, locale)
    return "${a.format(time)} – ${b.format(time)}"
}

@Composable
private fun SleepReportChart(report: SleepReport, zone: ZoneId, locale: Locale) {
    var zoom by remember(report.window) { mutableIntStateOf(1) }
    var pan by remember(report.window) { mutableFloatStateOf(0f) }
    var cursor by remember(report.window) { mutableFloatStateOf(0f) }
    val full = report.window.duration.seconds.toDouble().coerceAtLeast(1.0)
    val width = full / zoom
    val from = (full - width) * pan
    fun instant(fraction: Float): Instant =
        report.window.start.plusSeconds(
            (from + width * fraction).toLong().coerceAtMost(full.toLong() - 1)
        )
    val picked = instant(cursor)
    val stage =
        report.spans.firstOrNull { picked >= it.start && picked < it.end }?.stage
            ?: SleepStage.UNKNOWN
    val scheme = MaterialTheme.colorScheme
    val colors =
        mapOf(
            SleepStage.AWAKE to scheme.tertiary,
            SleepStage.LIGHT to scheme.secondary,
            SleepStage.DEEP to scheme.primary,
            SleepStage.UNKNOWN to scheme.outline,
        )
    val rows =
        if (report.totals.complete) listOf(SleepStage.AWAKE, SleepStage.LIGHT, SleepStage.DEEP)
        else SleepStage.entries
    fun label(value: SleepStage) = value.name.lowercase().replaceFirstChar { it.titlecase(locale) }
    val clock =
        DateTimeFormatter.ofPattern(
            if (report.window.start.atZone(zone).offset != report.window.end.atZone(zone).offset)
                "HH:mm XXX"
            else "HH:mm",
            locale,
        )
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Sleep stages", style = MaterialTheme.typography.titleLarge)
            Text(
                picked.atZone(zone).format(clock) + " · " + label(stage),
                style = MaterialTheme.typography.labelLarge,
                color = scheme.primary,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val chartHeight = if (rows.size == 3) 130.dp else 164.dp
                Column(
                    Modifier.width(52.dp).height(chartHeight),
                    verticalArrangement = Arrangement.SpaceAround,
                ) {
                    rows.forEach { row ->
                        Text(
                            label(row),
                            color = colors.getValue(row),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
                Canvas(
                    Modifier.weight(1f)
                        .height(chartHeight)
                        .semantics {
                            contentDescription =
                                "Sleep stages chart. Drag to inspect. Unknown intervals are gray."
                        }
                        .pointerInput(report, from, width) {
                            detectTapGestures { cursor = (it.x / size.width).coerceIn(0f, 1f) }
                        }
                        .pointerInput(report, from, width) {
                            detectDragGestures { change, _ ->
                                cursor = (change.position.x / size.width).coerceIn(0f, 1f)
                                change.consume()
                            }
                        }
                ) {
                    val rowHeight = size.height / rows.size
                    val thickness = 20.dp.toPx()
                    clipRect {
                        for (span in report.spans) {
                            val left =
                                ((Duration.between(report.window.start, span.start).seconds -
                                        from) / width * size.width)
                                    .toFloat()
                            val right =
                                ((Duration.between(report.window.start, span.end).seconds - from) /
                                        width * size.width)
                                    .toFloat()
                            val row = rows.indexOf(span.stage)
                            if (row >= 0)
                                drawRoundRect(
                                    colors.getValue(span.stage),
                                    Offset(left, rowHeight * (row + .5f) - thickness / 2),
                                    Size((right - left).coerceAtLeast(0f), thickness),
                                    CornerRadius(4.dp.toPx()),
                                )
                        }
                        drawLine(
                            scheme.onSurface.copy(alpha = .7f),
                            Offset(cursor * size.width, 0f),
                            Offset(cursor * size.width, size.height),
                            2.dp.toPx(),
                        )
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(start = 60.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    instant(0f).atZone(zone).format(clock),
                    style = MaterialTheme.typography.labelSmall,
                )
                Text(
                    report.window.start
                        .plusSeconds(Math.round(from + width))
                        .atZone(zone)
                        .format(clock),
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 4).forEach { scale ->
                    FilterChip(zoom == scale, { zoom = scale }, { Text("${scale}×") })
                }
            }
            if (zoom > 1)
                Slider(
                    state = rememberSliderState(value = pan),
                    onValueChange = { pan = it },
                    onValueChangeFinished = {},
                    modifier = Modifier.semantics { contentDescription = "Scroll timeline" },
                )
            if (report.totals.complete)
                Text(
                    listOf(SleepStage.AWAKE, SleepStage.LIGHT, SleepStage.DEEP).joinToString(
                        "  ·  "
                    ) {
                        val minutes = report.totals.duration(it).toMinutes()
                        "${label(it)} ${minutes/60}h ${minutes%60}min"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant,
                )
        }
    }
}

@Composable
private fun SleepMetricHistory(
    reports: List<SleepReport>,
    end: LocalDate,
    zone: ZoneId,
    metric: SleepDashboardMetric,
) {
    var days by remember(metric) { mutableIntStateOf(7) }
    var pickedIndex by remember(metric, days) { mutableStateOf<Int?>(null) }
    val points =
        remember(reports, end, days, zone, metric) {
            sleepMetricDays(reports, end, days, zone, metric)
        }
    val values = points.mapNotNull { it.value }
    val average = values.takeIf { it.isNotEmpty() }?.average()
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(metric.label, style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(7, 30, 90).forEach { count ->
                FilterChip(days == count, { days = count }, { Text("${count}d") })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Average", style = MaterialTheme.typography.labelLarge)
                Text(
                    metric.format(average),
                    style = MaterialTheme.typography.headlineLarge,
                    color = scheme.primary,
                )
            }
            Column {
                Text("Days included", style = MaterialTheme.typography.labelLarge)
                Text("${values.size} / $days", style = MaterialTheme.typography.headlineLarge)
            }
        }
        Text("Longest recorded session each day", style = MaterialTheme.typography.bodySmall)
        val max = (values.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
        Canvas(
            Modifier.fillMaxWidth()
                .height(160.dp)
                .semantics {
                    contentDescription =
                        "${metric.label} history. Missing values are gaps. Tap or drag to select a date."
                }
                .pointerInput(points) {
                    detectTapGestures {
                        pickedIndex =
                            (it.x / size.width * points.size).toInt().coerceIn(points.indices)
                    }
                }
                .pointerInput(points) {
                    detectDragGestures { change, _ ->
                        pickedIndex =
                            (change.position.x / size.width * points.size)
                                .toInt()
                                .coerceIn(points.indices)
                        change.consume()
                    }
                }
        ) {
            val column = size.width / points.size
            points.forEachIndexed { index, point ->
                point.value?.let { value ->
                    val height = (value / max * size.height).toFloat().coerceAtLeast(2.dp.toPx())
                    drawRoundRect(
                        if (index == pickedIndex) scheme.primary else scheme.primaryContainer,
                        Offset(index * column + column * .15f, size.height - height),
                        Size(column * .7f, height),
                        CornerRadius(4.dp.toPx()),
                    )
                }
            }
        }
        val selected = pickedIndex?.let { points[it] }
        Text(
            selected?.let { "${it.date} · ${metric.format(it.value)}" }
                ?: "Tap the chart to inspect a date.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(points.first().date.toString(), style = MaterialTheme.typography.labelSmall)
            Text(end.toString(), style = MaterialTheme.typography.labelSmall)
        }
        Text(
            "Missing or incomplete values are excluded from the average.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
