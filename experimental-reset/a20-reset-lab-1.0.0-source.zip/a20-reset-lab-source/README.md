# A20 Reset Lab public source

Corresponding GPL-3.0-only source for the separate experimental Reset Lab app.
Public package: `io.github.bytenomad47.a20.resetlab`. Version: `1.0.0-reset-lab`.

Only the manual-reset firmware-version gate is bypassed. Original A6611 device
filtering, single-ear isolation, known-response/voltage checks and fresh consent
remain. Real firmware 01.58 behavior is unverified. Acknowledgement does not prove
main-counter zero, persistence, or charging recovery. This installs no firmware.
Official 01.50 does not expose the diagnostic interface used by this repair.

Use a complete JDK 21 and Android SDK 37. From this directory:

```sh
python scripts/bootstrap_android.py
export ANDROID_HOME="$PWD/.tools/android-sdk"
./gradlew :app:testDebugUnitTest --tests '*repair.*'
./gradlew -Pa20ResetLab=true :app:assembleRelease :app:lintRelease
```

Release signing is optional: A20_SIGNING_STORE and A20_SIGNING_PASSWORD select a
local keystore outside this source tree, with alias a20-companion. Signing keys
and passwords are not included. The normal Companion project defaults preserve
its firmware restriction; use -Pa20ResetLab=true for this separate research app.

See docs/RESET_LAB.md for the procedure, retained checks and limitations.
No account credentials, captures, personal device identifiers or firmware images
are bundled. Product images retain their underlying rights; see NOTICE.
